# pixfly-html
HTML version of Pixfly
Designed by Dcrazed.com
https://dcrazed.com/pixfly-portfolio-website-template/ 

#License
Free for using on your website and client projects. 
Please dont sell this template. Why? Its free.

#WordPress
Need WordPress version? Look out for it in 
https://dcrazed.com/themes/